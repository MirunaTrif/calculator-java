// File: src/test/java/CalculatorTest.java
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class CalculatorTest {

    @Test
    public void testAddition() {
        List<Float> numbers = new ArrayList<>(List.of(4f, 5f));
        List<String> operations = new ArrayList<>(List.of("+"));
        Calculator.Calculate(numbers, operations);
        assertEquals(9f, Calculator.finalResult, 0.001);
    }

    @Test
    public void testSubtraction() {
        List<Float> numbers = new ArrayList<>(List.of(10f, 3f));
        List<String> operations = new ArrayList<>(List.of("-"));
        Calculator.Calculate(numbers, operations);
        assertEquals(7f, Calculator.finalResult, 0.001);
    }

    @Test
    public void testMultiplication() {
        List<Float> numbers = new ArrayList<>(List.of(3f, 6f));
        List<String> operations = new ArrayList<>(List.of("*"));
        Calculator.Calculate(numbers, operations);
        assertEquals(18f, Calculator.finalResult, 0.001);
    }

    @Test
    public void testDivision() {
        List<Float> numbers = new ArrayList<>(List.of(12f, 4f));
        List<String> operations = new ArrayList<>(List.of("/"));
        Calculator.Calculate(numbers, operations);
        assertEquals(3f, Calculator.finalResult, 0.001);
    }

    @Test
    public void testDivisionByZero() {
        List<Float> numbers = new ArrayList<>(List.of(12f, 0f));
        List<String> operations = new ArrayList<>(List.of("/"));
        Calculator.Calculate(numbers, operations);
        assertTrue(Float.isInfinite(Calculator.finalResult));
    }

    @Test
    public void testOrderOfOperations() {
        List<Float> numbers = new ArrayList<>(List.of(5f, 3f, 2f));
        List<String> operations = new ArrayList<>(List.of("+", "*"));
        Calculator.Calculate(numbers, operations);
        assertEquals(11f, Calculator.finalResult, 0.001);
    }
}
